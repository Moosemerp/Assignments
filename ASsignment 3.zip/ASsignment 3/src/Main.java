/*Name: Carlos Mendez Monsanto
 *PantherID: 5964545
 *Assignment 3*
 *Currently missing the search function*/
public class Main {

	public static void main(String[] args) {
		
		BeginAssignment Three = new BeginAssignment();

	}

}
